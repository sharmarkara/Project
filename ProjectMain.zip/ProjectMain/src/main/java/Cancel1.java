import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Cancel1")
public class Cancel1 extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		
			try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("delete from payment where name=?");
		 
			ps.setString(1,a);
			
			
			ps.execute();
			PreparedStatement ps1=con.prepareStatement("delete from booking where name=?");
			 
			ps1.setString(1,a);
			ps1.execute();
			res.sendRedirect("index.html");
		
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}}