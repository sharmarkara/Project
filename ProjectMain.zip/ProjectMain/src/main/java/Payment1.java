import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Payment1")
public class Payment1 extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("Name");
		String b=req.getParameter("Booking_ID");
		String c=req.getParameter("DOB");
		String d=req.getParameter("Amount");
		
			try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into payment values(?,?,?,?)");
			ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			
			
			ps.execute();
			res.sendRedirect("index.html");
		
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}}