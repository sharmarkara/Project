
function showhide(){ 
if(document.getElementById('reason').value == 'Other'){
document.getElementById('txtarea').style.display = 'block';
}
else{
document.getElementById('txtarea').style.display = 'none';
}
}
